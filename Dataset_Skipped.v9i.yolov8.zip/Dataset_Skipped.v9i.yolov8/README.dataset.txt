# Dataset_Skipped > 2025-01-10 4:54pm
https://universe.roboflow.com/visionx-1ipou/dataset_skipped

Provided by a Roboflow user
License: CC BY 4.0

